/** Automatically generated file. DO NOT MODIFY */
package org.jcodec.jcodec_samples;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}