package org.jcodec.jcodec_samples;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.jcodec.api.FrameGrab.MediaInfo;
import org.jcodec.api.JCodecException;
import org.jcodec.api.android.FrameGrab;
import org.jcodec.common.FileChannelWrapper;
import org.jcodec.common.NIOUtils;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;
import ar.com.daidalos.afiledialog.FileChooserDialog;
import ar.com.daidalos.afiledialog.FileChooserDialog.OnFileSelectedListener;

public class MainActivity extends Activity {

	public boolean flag = false;
	String lastPicture = "";
	private ImageView image;
	Boolean finish = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		image = (ImageView) findViewById(R.id.test_image);
		Button b1 = (Button) findViewById(R.id.stop);
	    b1.setOnClickListener(myhandler1);
	}
	
	View.OnClickListener myhandler1 = new View.OnClickListener() {
	    public void onClick(View v) {
	    	if(finish == false){
	    		finish = true;
	    	}
	    	else if(finish == true){
	    		finish = false;
	    	}
	    }
	  };

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void startDecode(View view) {
		FileChooserDialog dialog = new FileChooserDialog(view.getContext());
		dialog.addListener(new OnFileSelectedListener() {
			@Override
			public void onFileSelected(Dialog source, File folder, String name) {
			}
	
			@Override
			public void onFileSelected(Dialog source, File file) {
					source.hide();
				new Decoder().execute(file);
			}
		});
		dialog.show();
	}

	private class Decoder extends AsyncTask<File, Integer, Integer> {
		private static final String TAG = "DECODER";

		protected Integer doInBackground(File... params) {
			FileChannelWrapper ch = null;
			while(finish == false){
			try {
				ch = NIOUtils.readableFileChannel(params[0]);
				FrameGrab frameGrab = new FrameGrab(ch);
				MediaInfo mi = frameGrab.getMediaInfo();

				Bitmap frame = Bitmap.createBitmap(mi.getDim().getWidth(), mi.getDim().getHeight(), Bitmap.Config.ARGB_8888);
				
				for (int i=0; i<=35; i++) {
					while(finish==true){};
					if(frame != null){
						frameGrab.getFrame(frame);
						OutputStream os = null;
						try {
							lastPicture = String.format("img%08d.jpg", i);
							os = new BufferedOutputStream(new FileOutputStream(
							new File(params[0].getParentFile(), lastPicture)));
							frame.compress(CompressFormat.JPEG, 90, os);
						}
						finally {
							if (os != null)
								os.close();
						}
						publishProgress(i);
					}
				}
			} catch (IOException e) {
				Log.e(TAG, "IO", e);
			} catch (JCodecException e) {
				Log.e(TAG, "JCodec", e);
			} finally {
				NIOUtils.closeQuietly(ch);
			}
			}
			return null;
		}
			

		@Override
		protected void onProgressUpdate(Integer... values) {
			Bitmap bMap = BitmapFactory.decodeFile("/sdcard/test/"+lastPicture);
	        image.setImageBitmap(bMap);
		}
	}
}