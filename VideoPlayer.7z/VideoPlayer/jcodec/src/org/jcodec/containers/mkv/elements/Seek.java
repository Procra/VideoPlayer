package org.jcodec.containers.mkv.elements;

public class Seek {
    
    public byte[] seekId;
    public long seekPosition;

}
