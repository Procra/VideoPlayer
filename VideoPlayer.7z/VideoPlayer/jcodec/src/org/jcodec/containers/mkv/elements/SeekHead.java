package org.jcodec.containers.mkv.elements;

import org.jcodec.containers.mkv.ebml.MasterElement;

public class SeekHead extends MasterElement {

    public SeekHead(byte[] type) {
        super(type);
    }

}
