package org.jcodec.containers.mkv.elements;

import org.jcodec.containers.mkv.ebml.MasterElement;

public class Tracks extends MasterElement {

    public Tracks(byte[] type) {
        super(type);
    }

}
