package org.jcodec.api;

public class UnsupportedFormatException extends JCodecException {

    public UnsupportedFormatException(String arg0) {
        super(arg0);
    }
}
