package org.jcodec.api;

public class JCodecException extends Exception {

    public JCodecException(String arg0) {
        super(arg0);
    }
}
