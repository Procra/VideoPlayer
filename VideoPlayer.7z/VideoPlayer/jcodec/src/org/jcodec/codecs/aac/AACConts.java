package org.jcodec.codecs.aac;

public class AACConts {

    public static int[] AAC_SAMPLE_RATES = { 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000,
            11025, 8000, 7350 };
}
